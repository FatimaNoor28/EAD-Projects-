function myfunction(){
    alert("Your appointment request has been sent successfully. Thank you!");
}